---
name: Dhara Heritage
colors:
  surface: '#fbf9f4'
  surface-dim: '#dbdad5'
  surface-bright: '#fbf9f4'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3ee'
  surface-container: '#f0eee9'
  surface-container-high: '#eae8e3'
  surface-container-highest: '#e4e2dd'
  on-surface: '#1b1c19'
  on-surface-variant: '#524438'
  inverse-surface: '#30312e'
  inverse-on-surface: '#f2f1ec'
  outline: '#857466'
  outline-variant: '#d7c3b3'
  surface-tint: '#8b5000'
  primary: '#693b00'
  on-primary: '#ffffff'
  primary-container: '#8a5000'
  on-primary-container: '#ffcfa2'
  inverse-primary: '#ffb870'
  secondary: '#24695c'
  on-secondary: '#ffffff'
  secondary-container: '#acf0df'
  on-secondary-container: '#2b6f62'
  tertiary: '#394d00'
  on-tertiary: '#ffffff'
  tertiary-container: '#4c6600'
  on-tertiary-container: '#c3e476'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdcbe'
  primary-fixed-dim: '#ffb870'
  on-primary-fixed: '#2c1600'
  on-primary-fixed-variant: '#693c00'
  secondary-fixed: '#acf0df'
  secondary-fixed-dim: '#90d3c3'
  on-secondary-fixed: '#00201a'
  on-secondary-fixed-variant: '#005045'
  tertiary-fixed: '#ceef80'
  tertiary-fixed-dim: '#b2d267'
  on-tertiary-fixed: '#151f00'
  on-tertiary-fixed-variant: '#394d00'
  background: '#fbf9f4'
  on-background: '#1b1c19'
  surface-variant: '#e4e2dd'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 80px
    fontWeight: '700'
    lineHeight: 88px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '400'
    lineHeight: 32px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  label-caps:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.15em
  button:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  container-padding: 4rem
  container-padding-mobile: 1.5rem
  stack-gap: 2rem
  asymmetric-offset: 3rem
  grid-gutter: 24px
---

## Brand & Style
The design system embodies a "Premium Editorial Spirituality"—a sophisticated synthesis of ancient cultural roots and contemporary minimalist luxury. The target audience includes modern patrons, scholars, and spiritual seekers who value both tradition and refined aesthetics.

The visual style is **Modern Editorial with Asymmetric Depth**. It relies on high-end typography and a "restrained maximalism" where a single, powerful visual moment—often a high-contrast photograph—is layered with floating, translucent UI elements. The interface should feel like a premium printed journal: spacious, rhythmic, and intentional. We utilize glassmorphism and soft tactile layers to create a sense of lightness, suggesting that the digital interface is a gentle overlay upon the physical world of heritage and tradition.

## Colors
This design system utilizes a palette inspired by sacred materials: parchment, saffron, oxidized copper, and deep forest canopies. 

The primary background is a warm parchment (`#fbf9f4`), which provides a softer, more organic feel than pure white. **Deep Forest** is reserved for high-impact immersive sections to create a sense of sanctuary and focus. **Saffron** serves as the primary spiritual anchor, used for calls to action and key highlights. **Gold Detail** should be used sparingly for hairline borders, icons, or small decorative flourishes to denote premium status and sacredness.

## Typography
The typographic hierarchy is defined by extreme contrast. Large-scale **Playfair Display** headlines provide a sense of authority and timelessness. These should be paired with generous whitespace to allow the letterforms to breathe. 

**Plus Jakarta Sans** provides a clean, modern counterpoint for functional text and UI elements, ensuring the system remains accessible and usable. **Label-caps** should be used for category headers, small metadata, and eyebrows above headlines to establish a clear information architecture. Maintain a high "scale jump" between display text and body text to reinforce the editorial narrative.

## Layout & Spacing
The layout follows a 12-column fluid grid but breaks it frequently to achieve **confident asymmetry**. Elements should often be "offset" from the grid—for example, a text block might overlap the edge of an image by 48px to create depth.

Large containers use a "safe margin" of 64px on desktop to pull content toward the center, creating an intimate, focused reading experience. On mobile, transition to a single-column layout with 24px gutters. Use "Photography-first" composition: when text is placed over images, use glassmorphic backing or gradient scrims (using the Deep Forest or Saffron tones) to ensure legibility while maintaining the visual integrity of the photography.

## Elevation & Depth
Depth is created through a combination of **Glassmorphism** and **Asymmetric Layering**. 

1.  **Level 0 (Base):** The parchment background or full-bleed photography.
2.  **Level 1 (Surface):** Cards and containers with `surface-1` or `surface-2` fills. No shadows, just subtle 1px outlines in `outline-soft`.
3.  **Level 2 (Floating/Glass):** Floating UI elements (modals, search bars, navigation) use a backdrop blur (12px to 20px) with a semi-transparent white or parchment fill (30-60% opacity). They feature a thin 1px light border and a soft, extremely diffused shadow (e.g., `box-shadow: 0 20px 40px rgba(0,0,0,0.04)`).

Overlapping elements should feel intentional; a card might sit 50% on a dark image and 50% on a light surface to bridge the two visual zones.

## Shapes
The shape language is defined by oversized, welcoming curves that suggest organic flow and safety. 

- **Hero & Primary Containers:** Use a dominant 40px radius to frame high-level sections.
- **Cards & Surface Elements:** Use a 24px radius to provide a modern, premium feel.
- **Functional Elements:** Buttons, tags, and input fields utilize full "pill" shapes (999px radius). This contrast between the large structural curves of containers and the sleek pills of the UI components creates a sophisticated, balanced aesthetic.

## Components

### Buttons & Chips
Buttons are always pill-shaped. The primary button uses the `accent-saffron` fill with white text. The secondary button is an "outline pill" using the `gold-detail` or `outline` color. Chips (tags) follow the pill shape but use `surface-3` with `label-caps` typography.

### Cards
Cards should feel like editorial snippets. They use the 24px radius and can either be flat `surface-1` or glassmorphic overlays. Avoid heavy borders; use subtle shadows or color-blocking to define edges.

### Input Fields
Inputs are pill-shaped with a subtle `outline-soft` border. Labels for inputs should always use the `label-caps` style placed above the field with a 8px gap.

### Lists & Navigation
Navigation items use `label-caps` with a horizontal gold underline on hover. Lists should be spaced generously, using the `gold-detail` color for small bullet flourishes or icons to maintain the premium feel.

### Lists & Overlays
When UI elements sit on photography, ensure a 12px backdrop blur is applied to the component background to maintain the "Glassmorphism" design intent and ensure the `text-main` remains legible against busy backgrounds.